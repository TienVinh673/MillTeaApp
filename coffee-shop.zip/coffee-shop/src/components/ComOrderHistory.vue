<template>
  <div class="order-history-container">
    <h2>Lịch sử thanh toán</h2>
    <div v-if="userOrders.length === 0" class="empty-history">
      <p>Chưa có lịch sử thanh toán</p>
    </div>
    <ul v-else class="order-list">
      <li v-for="order in userOrders" :key="order.id" class="order-item">
        <div class="order-header">
          <p class="order-id">Mã đơn hàng: #{{ order.id }}</p>
          <p class="order-date">Ngày: {{ formatDate(order.date) }}</p>
        </div>
        <div class="order-products">
          <div v-for="item in order.items" :key="item.id" class="order-product">
            <img :src="item.image" :alt="item.name" class="product-image">
            <div class="product-details">
              <p class="product-name">{{ item.name }}</p>
              <p class="product-quantity">Số lượng: {{ item.quantity }}</p>
              <p v-if="item.selectedSize">Size: {{ item.selectedSize }}</p>
            </div>
          </div>
        </div>
        <div class="order-footer">
          <p class="order-total">Tổng tiền: {{ formatPrice(order.total) }}</p>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
import orderHistory from '../data/orderHistory'

export default {
  data() {
    return {
      currentUser: null,
      orderHistory: orderHistory
    }
  },
  computed: {
    userOrders() {
      if (!this.currentUser) return []
      return this.orderHistory[this.currentUser.username] || []
    }
  },
  created() {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'))
    if (!this.currentUser) {
      this.$router.push('/login')
    }
  },
  methods: {
    formatDate(date) {
      return new Date(date).toLocaleDateString('vi-VN')
    },
    formatPrice(price) {
      return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
      }).format(price)
    }
  }
}
</script>

<style scoped>
.order-history-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 100px 20px 40px;
}

.empty-history {
  text-align: center;
  padding: 40px;
  background: #f8f9fa;
  border-radius: 8px;
}

.order-list {
  list-style: none;
  padding: 0;
}

.order-item {
  background: white;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.order-header {
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid #eee;
  padding-bottom: 10px;
  margin-bottom: 15px;
}

.order-products {
  margin: 15px 0;
}

.order-product {
  display: flex;
  gap: 15px;
  margin-bottom: 10px;
  padding: 10px;
  background: #f8f9fa;
  border-radius: 4px;
}

.product-image {
  width: 80px;
  height: 80px;
  object-fit: cover;
  border-radius: 4px;
}

.product-details {
  flex: 1;
}

.product-name {
  font-weight: bold;
  margin-bottom: 5px;
}

.order-footer {
  border-top: 1px solid #eee;
  padding-top: 15px;
  text-align: right;
}

.order-total {
  font-weight: bold;
  color: #e44d26;
  font-size: 1.1em;
}
</style>